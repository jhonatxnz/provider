package br.com.jhonatan.provider.controller;

import br.com.jhonatan.provider.dto.TokenResponse;
import br.com.jhonatan.provider.service.AuthenticationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping(RestControllerUrlBase.BASE_URL + "/authentication")
public class AuthenticationController {

    private final AuthenticationService authenticationService;

    // POST /api/authentication/tokens
    // Cria um novo token de acesso usado pelo client parceiro.
    @PostMapping("/tokens")
    public TokenResponse createToken() {
        return authenticationService.createToken();
    }
}
