package br.com.jhonatan.provider.controller;

import br.com.jhonatan.provider.dto.CustomerRequest;
import br.com.jhonatan.provider.dto.CustomerResponse;
import br.com.jhonatan.provider.dto.StatusResponse;
import br.com.jhonatan.provider.service.CustomersService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping(RestControllerUrlBase.BASE_URL + "/customers")
public class CustomersController {

    private final CustomersService customersService;

    // GET /api/customers/{username}
    @GetMapping("/{username}")
    public CustomerResponse getCustomer(@PathVariable String username) {
        return customersService.getByUsername(username);
    }

    // POST /api/customers
    @PostMapping
    public StatusResponse createCustomer(@RequestBody CustomerRequest request) {
        return customersService.create(request);
    }

    // PUT /api/customers
    @PutMapping
    public StatusResponse updateCustomer(@RequestBody CustomerRequest request) {
        return customersService.update(request);
    }
}
