package br.com.jhonatan.provider.controller;

/**
 * Constantes de path compartilhadas pelos controllers.
 * Não é um @RestController: só concentra o prefixo base "/api" usado nos outros controllers.
 */
public final class RestControllerUrlBase {

    public static final String BASE_URL = "/api";

    private RestControllerUrlBase() {
    }
}
