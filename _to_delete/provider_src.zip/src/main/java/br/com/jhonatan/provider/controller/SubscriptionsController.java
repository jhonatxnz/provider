package br.com.jhonatan.provider.controller;

import br.com.jhonatan.provider.dto.StatusResponse;
import br.com.jhonatan.provider.dto.SubscriptionRequest;
import br.com.jhonatan.provider.dto.SubscriptionSummary;
import br.com.jhonatan.provider.service.SubscriptionsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(RestControllerUrlBase.BASE_URL + "/customers/{username}/subscriptions")
public class SubscriptionsController {

    private final SubscriptionsService subscriptionsService;

    // GET /api/customers/{username}/subscriptions
    @GetMapping
    public List<SubscriptionSummary> listSubscriptions(@PathVariable String username) {
        return subscriptionsService.list(username);
    }

    // POST /api/customers/{username}/subscriptions
    @PostMapping
    public StatusResponse createSubscription(@PathVariable String username,
                                              @RequestBody SubscriptionRequest request) {
        return subscriptionsService.subscribe(username, request);
    }

    // DELETE /api/customers/{username}/subscriptions/{subscription}
    // Obs: o documento original descrevia esse endpoint como POST, mas por ser uma remoção
    // deixei como DELETE (mais alinhado a REST). Troque para @PostMapping se preferir seguir
    // o documento original à risca.
    @DeleteMapping("/{subscription}")
    public StatusResponse deleteSubscription(@PathVariable String username,
                                              @PathVariable String subscription) {
        return subscriptionsService.cancel(username, subscription);
    }
}
