package br.com.jhonatan.provider.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "users_subscriptions")
public class UserSubscriptions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Modelado como coluna simples (bate com o DDL). Troque por @ManyToOne
    // para Subscriptions/Users se preferir navegar o relacionamento via JPA.
    @Column(name = "subscription_id", nullable = false)
    private Long subscriptionId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "canceled_at")
    private LocalDateTime canceledAt;

    // '1' - active, '0' - inactive, '2' - block (ver COMMENT original da coluna no DDL)
    @Column(name = "status", nullable = false, length = 30)
    private String status;

    // email do usuário no momento em que a assinatura foi ativada
    @Column(name = "email")
    private String email;

    // telefone do usuário no momento em que a assinatura foi ativada
    @Column(name = "phone", length = 30)
    private String phone;
}
