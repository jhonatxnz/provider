package br.com.jhonatan.provider.service;

import br.com.jhonatan.provider.dto.CustomerRequest;
import br.com.jhonatan.provider.dto.CustomerResponse;
import br.com.jhonatan.provider.dto.StatusResponse;
import br.com.jhonatan.provider.repository.UsersRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomersServiceImpl implements CustomersService {

    private final UsersRepository usersRepository;

    @Override
    public CustomerResponse getByUsername(String username) {
        // TODO: buscar cliente + assinaturas pelo username
        throw new UnsupportedOperationException("TODO: CustomersServiceImpl.getByUsername");
    }

    @Override
    public StatusResponse create(CustomerRequest request) {
        // TODO: criar cliente
        throw new UnsupportedOperationException("TODO: CustomersServiceImpl.create");
    }

    @Override
    public StatusResponse update(CustomerRequest request) {
        // TODO: atualizar cliente
        throw new UnsupportedOperationException("TODO: CustomersServiceImpl.update");
    }
}
